import $ from 'jquery';
import 'slick-carousel';
import scripts from './modules/scripts';

scripts();

console.log('bundle working 2');