export default function() {

	jQuery(document).ready(function($) {

		$('header').on('click', '.header__menu-toggle', function(event) {
			var header = $('header');

			event.preventDefault();
			header.find('.header__menu-toggle').toggleClass('show');
			header.find('.header__menu').toggleClass('show');
			$('.header__overlay').toggleClass('show');

		});

		$('header').on('click', 'a[href^="#"]', function (event) {
			var header = $('header');

		    event.preventDefault();
		    console.log('anchor');

		    $('html, body').animate({
		        scrollTop: $($.attr(this, 'href')).offset().top
		    }, 500);

		    header.find('.header__menu').removeClass('show');
		    header.find('.header__menu-toggle').toggleClass('show');
			$('.header__overlay').removeClass('show');
		});

		$('body').on('click', '.header__overlay', function(event) {
			var header = $('header');

			event.preventDefault();
			$(this).toggleClass('show');
			header.find('.nav-primary').toggleClass('show');
		});

		$('.home-projects__item').on('click', function() {
			var $project = $(this),
				$projectInner = $project.find('.home-projects__item-inner')
				$projectTitle = $projectInner.find('.home-projects__item-title'),
				$projectClone = $projectInner.clone(true, true),
				height = $projectInner.outerHeight(),
				$projectOverlay = $('.home-projects__overlay');

			$([document.documentElement]).animate({ scrollTop: $(this).offset().top }, 500);

			window.history.replaceState('page2', 'Title', '/project.html');

			$projectClone
				.insertBefore('.page-content')
				.addClass('clone')
				.css({
					position: 'fixed',
			 	    top: 0,
			 	    left: $projectInner.offset().left,
			 	    width: $projectInner.outerWidth(),
			 	    height: height
				})

			$projectClone
				.animate({
					opacity: 1,
				}, 500);

			$projectClone.find('.home-projects__item-title').fadeOut(500);

			$projectClone.delay(500).queue(function(){
				$(this).animate({
					'left': 0,
					'width': '100%'
				}, 500).dequeue();

				$projectClone.find('.home-projects__item-image').addClass('full');

				$('.home-projects__overlay').addClass('visible').dequeue();
				$([document.documentElement]).delay(500).queue(function(){
					$(this).animate({
						scrollTop: 0
					}, 0).dequeue();
					$projectClone.css({ position: 'relative' });
					$('.page-content').load("project.html .project-body");
					$('.home-projects__overlay').removeClass('visible').dequeue();
				});
			});

			console.log($projectClone.find('.home-projects__item-image'));

		    	//$('.home-projects__overlay').removeClass('visible').hide();
		    	//$projectImage.css({ position: 'relative' });
				//$('.page-content').load("project.html .project-body");

		});

		(function() {

			var $homeIndication = $('.home-gallery__indication'),
				$homeGallery = $('.home-gallery__slider');

			$homeGallery.on('init reInit beforeChange', function(event, slick, currentSlide, nextSlide){
			    //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
			    var i = (currentSlide ? currentSlide : 0) + 1;
			    $homeIndication.text(('0' + i).slice(-2) + ' / ' + ('0' + slick.slideCount).slice(-2));
			});

			$homeGallery.slick({
				infinite: true,
		        centerMode: true,
		        variableWidth: true,
		        prevArrow: $('.home-gallery__prev'),
		        nextArrow: $('.home-gallery__next'),
			});

			var $testimonials = $('.home-testimonials__inner');

			$testimonials.slick({
				fade: true,
				prevArrow: $('.home-testimonials__prev'),
		        nextArrow: $('.home-testimonials__next'),
			});
		})();

		function serviceIndicator() {

			var $bar = $('.services-breakdown__indicator'),
				$line = $bar.find('div');

			// $line.height(windowMiddle);
			// console.log($line);

			$(window).on( 'scroll', function(){
				var windowHeight = $(window).height(),
					windowMiddle = windowHeight * .5,
					scrollTop     = $(window).scrollTop(),
					elementOffset = $('.services-breakdown__indicator').offset().top,
					distance      = (elementOffset - scrollTop),
					scrollMiddle = scrollTop + windowMiddle,
					hello = scrollMiddle - elementOffset,
					height = distance - windowMiddle;

				$line.height(hello);
			});

		} serviceIndicator(); 

		var userFeed = new Instafeed({
			get: 'user',
			userId: '8987997106',
			clientId: '924f677fa3854436947ab4372ffa688d',
			accessToken: '8987997106.924f677.8555ecbd52584f41b9b22ec1a16dafb9',
			resolution: 'standard_resolution',
			template: '<a href="{{link}}" target="_blank" id="{{id}}"><img src="{{image}}" /></a>',
			sortBy: 'most-recent',
			limit: 5,
			links: false
		});
		userFeed.run();



	});

}