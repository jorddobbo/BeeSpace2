<?php

# Template Name: About

get_header() ?>

<div class="page-hero">
		<div class="page__container container">
			<div class="page-hero__inner">
				<div class="page-hero__left">
					<div class="page-hero__left-inner">
						<h1 class="page-hero__title title">About<br><span class="title__highlight">BeeSpace</span></h1>
						<p class="page-hero__paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by branding the houses she owned.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="page-hero__right" style="background-image: url('<?= get_template_directory_uri(); ?>/assets/img/projects/project_wallbrook.jpg');">
		</div>
		<section class="pattern pattern--triangle"></section>
	</div>

	<section class="about-jade">
		<div class="about-jade__container container">
			<div class="about-jade__row">
				<div class="about-jade__half"><img src="<?= get_template_directory_uri(); ?>/assets/img/img_jade.jpg" alt="Intro"/></div>
				<div class="about-jade__half">
					<div class="about-jade__half-inner">
						<h2 class="about-jade__title">Jade<br>Bailey</h2>
						<p class="about-jade__paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by branding the houses she owned. <br><br> Lorem ipsum. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by branding the houses she owned. Lorem ipsum. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by branding the houses she owned. </p>
						<div class="about-jade__social">
							<a href="/"><img src="<?= get_template_directory_uri(); ?>/assets/img/social_in-dark.svg" /></a>
							<a href="/"><img src="<?= get_template_directory_uri(); ?>/assets/img/social_tw-dark.svg" /></a>
							<a href="/"><img src="<?= get_template_directory_uri(); ?>/assets/img/social_fb-dark.svg" /></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="home-testimonials">
		<div class="container home-testimonials__container">
			<div class="home-testimonials__icon">
				<img src="<?= get_template_directory_uri(); ?>/assets/img/icon_quote.svg" />
			</div>
			<div class="home-testimonials__inner">
				<div class="home-testimonials__item">
					<h3 class="home-testimonials__title">For me the experience of the house should start out on the street. </h3>
					<p class="home-testimonials__paragraph">Most investors don’t see the importance of it but first impression is everything. I’m incredibly passionate about design, it needs to have an impact on you and create a memory.  I like to create aspirational places for people to live in, work in or even both at the same time. 
					<br><br>
					The difference between a creative concept and just items in a room, is when the small details connect to the overall look  within the space. So everything looks and feels cohesive and ultimately creates a unique experience. This is how you Brand Your Space</p>
				</div>
			</div>
		</div>
	</section>

	<section class="footer-chat">
		<div class="footer-chat__container container">
			<h2 class="footer-chat__title">Want to chat? <img src="<?= get_template_directory_uri(); ?>/assets/img/icon_arrow-dark-right.svg"></h2>
		</div>
	</section>


<?php get_footer() ?>