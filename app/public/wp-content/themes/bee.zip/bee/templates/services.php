<?php

# Template Name: Services

get_header() ?>

<div class="page-hero">
		<div class="page__container container">
			<div class="page-hero__inner">
				<div class="page-hero__left">
					<div class="page-hero__left-inner">
						<h1 class="page-hero__title title">Our<br><span class="title__highlight">Services</span></h1>
						<p class="page-hero__paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by branding the houses she owned.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="page-hero__right" style="background-image: url('<?= get_template_directory_uri(); ?>/assets/img/projects/project_wallbrook.jpg');">
		</div>
		<section class="pattern pattern--triangle"></section>
	</div>

	<section class="services-intro">
		<div class="services-intro__container container">
			<div class="services-intro__row">
				<div class="services-intro__third">
					<img class="services-intro__icon" src="<?= get_template_directory_uri(); ?>/assets/img/icon_plan.svg" alt="Intro"/>
					<h3 class="services-intro__title">Design</h3>
					<p class="services-intro__paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge.</p>
				</div>
				<div class="services-intro__third">
					<img class="services-intro__icon" src="<?= get_template_directory_uri(); ?>/assets/img/icon_bedroom.svg" alt="Intro"/>
					<h3 class="services-intro__title">Concept</h3>
					<p class="services-intro__paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge.</p>
				</div>
				<div class="services-intro__third">
					<img class="services-intro__icon" src="<?= get_template_directory_uri(); ?>/assets/img/icon_house-plan.svg" alt="Intro"/>
					<h3 class="services-intro__title">Investment</h3>
					<p class="services-intro__paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge.</p>
				</div>
			</div>
		</div>
	</section>

	<section class="services-breakdown">
		<div class="services-breakdown__container container">
			<div class="services-breakdown__top">
				<h2 class="services-breakdown__top-title">How it works</h2>
				<p class="services-breakdown__top-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by branding the houses she owned.</p>
			</div>
			<div class="services-breakdown__list">
				<div class="services-breakdown__indicator">
					<div></div>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>1</div>
					<h3 class="services-breakdown__item-title">The Brief</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>2</div>
					<h3 class="services-breakdown__item-title">The Concept</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>3</div>
					<h3 class="services-breakdown__item-title">Material Spec</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>4</div>
					<h3 class="services-breakdown__item-title">Furniture & Lightning</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>5</div>
					<h3 class="services-breakdown__item-title">Visit Site</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>6</div>
					<h3 class="services-breakdown__item-title">Source</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>7</div>
					<h3 class="services-breakdown__item-title">Install</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>8</div>
					<h3 class="services-breakdown__item-title">Photography</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
				<div class="services-breakdown__item">
					<div class="services-breakdown__item-number"><div></div>9</div>
					<h3 class="services-breakdown__item-title">To Market</h3>
					<p class="services-breakdown__item-paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by</p>
				</div>
			</div>
		</div>
	</section>

	<section class="services-projects">
		<div class="services-projects__container container">
			<div class="services-projects__left">
				<div class="services-projects__left-inner">
					<h1 class="services-projects__title title">View our<br><span class="title__highlight">Projects</span></h1>
					<p class="services-projects__paragraph">Jade Bailey is the Creative Director and founder of Beespace. As a property owner herself, she wanted to challenge the everyday perception of what a Co-living house could look and feel like by branding the houses she owned.</p>
					<a class="button" href="/">Our Work</a>
				</div>
			</div>
		</div>
		<div class="services-projects__right" style="background-image: url('<?= get_template_directory_uri(); ?>/assets/img/projects/project_wallbrook.jpg');">
		</div>
	</section>

	<section class="footer-chat">
		<div class="footer-chat__container container">
			<h2 class="footer-chat__title">Want to chat? <img src="<?= get_template_directory_uri(); ?>/assets/img/icon_arrow-dark-right.svg"></h2>
		</div>
	</section>

<?php get_footer() ?>