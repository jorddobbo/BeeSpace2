<section class="footer-instagram" id="instafeed"></section>

		<footer class="footer">
			<div class="container footer__container">
				<div class="footer__subscribe">
					<h4 class="footer__subscribe-title">STAY IN THE KNOW</h4>
					<p class="footer__subscribe-paragraph">Get the latest in all things Bee Space & property investment</p>
					<div class="footer__subscribe-form">
						<input type="email" class="footer__subscribe-input" placeholder="Enter your email address" />
						<button type="submit" class="button footer__subscribe-button">Join</button>
					</div>
				</div>
				<div class="footer__middle">
					<div class="footer__middle-item">
						<h6 class="footer__middle-subtitle">Get in touch</h6>
						<h4 class="footer__middle-title">07734883890</h4>
					</div>
					<div class="footer__middle-item">
						<h6 class="footer__middle-subtitle">Email us</h6>
						<h4 class="footer__middle-title">SEND AN EMAIL <img src="<?= get_template_directory_uri(); ?>/assets/img/icon_arrow-right.svg" /></h4>
					</div>
					<div class="footer__middle-item footer__middle-social">
						<h6 class="footer__middle-subtitle">Get in touch</h6>
						<a href="/"><img src="<?= get_template_directory_uri(); ?>/assets/img/social_in.svg" /></a>
						<a href="/"><img src="<?= get_template_directory_uri(); ?>/assets/img/social_tw.svg" /></a>
						<a href="/"><img src="<?= get_template_directory_uri(); ?>/assets/img/social_fb.svg" /></a>
					</div>
				</div>
				<div class="footer__bottom">
					<div class="footer__bottom-left">
						<img src="<?= get_template_directory_uri(); ?>/assets/img/logo-white.svg" /> © 2018 Bee Space. All rights reserved.
					</div>
					<div class="footer__bottom-right">
						<?php
			                if (has_nav_menu('primary_navigation')) :
			                  wp_nav_menu(['theme_location' => 'secondary_navigation', 'menu_class' => 'footer__bottom-menu']);
			                endif;
			              ?>
					</div>
				</div>
			</div>
		</footer>
		<section class="pattern pattern--triangle"></section>
	</div>

	<div class="home-projects__overlay"></div>

</body>

</html>

<?php wp_footer(); ?>