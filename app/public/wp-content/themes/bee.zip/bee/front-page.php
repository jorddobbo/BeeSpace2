<?php 

get_header();

$frontpage_id = get_option( 'page_on_front' );

?>

<div class="page-content">

	<section class="home-hero">
		<div class="container home-hero__container">
			<div class="home-hero__inner">
				<div class="home-hero__content">
					<h1 class="home-hero__title title">Be Original<span class="title__highlight">Think Differently</span></h1>
				</div>
				<div class="home-hero__indication">
					<img src="<?= get_template_directory_uri(); ?>/assets/img/icon_arrow.svg" />
				</div>
			</div>
		</div>
	</section>

	<section class="home-intro">
		<div class="container home-intro__container">
			<div class="home-intro__inner">
				<div class="home-intro__row">
					<div class="home-intro__half">
						<div class="home-intro__half-inner">
							<h1 class="home-intro__title">Brand<br>Your Space</h1>
							<p class="home-intro__paragraph">Beespace is a design-led creative property company. We specialise in creating Co-living and Co-working spaces with a difference. We design and develop creative concepts which are unique in design and memorable in experience.</p>
							<div class="home-intro__buttons">
								<a href="/projects" class="button home-intro__button">Our work</a>
								<a href="/projects" class="button home-intro__button button--outline">Learn more</a>
							</div>
						</div>
					</div>
					<div class="home-intro__half">
						<img src="<?= get_template_directory_uri(); ?>/assets/img/intro_1.jpg" alt="Intro"/>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="home-gallery">
		<div class="container home-gallery__container">
			<h2 class="home-gallery__title">Work with us</h2>
			<p class="home-gallery__paragraph">With bank interest rates at around an average of 1% it makes sense to make your money work for you. By choosing to invest into a property project with us we can guarantee you much more of a desirable return on your investment, and most importantly a working relationship you can trust. Why not come and follow us across our social media platforms to see what projects we are working on daily. </p>
			<div class="home-gallery__arrows">
				<div class="home-gallery__prev home-gallery__arrow">
					<img src="<?= get_template_directory_uri(); ?>/assets/img/icon_arrow-left.svg" />
				</div>
				<div class="home-gallery__next home-gallery__arrow">
					<img src="<?= get_template_directory_uri(); ?>/assets/img/icon_arrow-right.svg" />
				</div>
			</div>
		</div>
		<div class="home-gallery__slider">
			<div class="home-gallery__slide"><img src="<?= get_template_directory_uri(); ?>/assets/img/gallery/gallery_one.jpg" /></div>
			<div class="home-gallery__slide"><img src="<?= get_template_directory_uri(); ?>/assets/img/gallery/gallery_two.jpg" /></div>
			<div class="home-gallery__slide"><img src="<?= get_template_directory_uri(); ?>/assets/img/gallery/gallery_three.jpg" /></div>
		</div>
		<h6 class="home-gallery__indication"></h6>
	</section>

	<section class="pattern pattern--triangle"></section>

	<?php echo do_shortcode('[projects]'); ?>

	<!-- <section class="home-projects">
		<div class="container home-projects__container">
			<div class="home-projects__top">
				<h2 class="home-projects__title">Our Projects</h2>
				<a href="/" class="button home-projects__button">View all projects</a>
			</div>
			<div class="home-projects__list">
				<div class="home-projects__item home-projects__item--half">
					<div class="home-projects__item-inner">
						<h3 class="home-projects__item-title">Palmer<br>House</h3>
						<div class="home-projects__item-image" style="background-image: url('<?= get_template_directory_uri(); ?>/assets/img/projects/project_palmer.jpg');"></div>
					</div>
				</div>
				<div class="home-projects__item home-projects__item--half">
					<div class="home-projects__item-inner">
						<h3 class="home-projects__item-title">Garden<br>Lane</h3>
						<div class="home-projects__item-image" style="background-image: url('<?= get_template_directory_uri(); ?>/assets/img/projects/project_garden.jpg');"></div>
					</div>
				</div>
				<div class="home-projects__item home-projects__item--full">
					<div class="home-projects__item-inner">
						<h3 class="home-projects__item-title">Wallbrook<br>Road</h3>
						<div class="home-projects__item-image" style="background-image: url('<?= get_template_directory_uri(); ?>/assets/img/projects/project_wallbrook.jpg');"></div>
					</div>
				</div>
				<div class="home-projects__item home-projects__item--half">
					<div class="home-projects__item-inner">
						<h3 class="home-projects__item-title">Stanton<br>Place</h3>
						<div class="home-projects__item-image" style="background-image: url('<?= get_template_directory_uri(); ?>/assets/img/projects/project_stanton.jpg');"></div>
					</div>
				</div>
				<div class="home-projects__item home-projects__item--half">
					<div class="home-projects__item-inner">
						<h3 class="home-projects__item-title">Meadow<br>View Road</h3>
						<div class="home-projects__item-image" style="background-image: url('<?= get_template_directory_uri(); ?>/assets/img/projects/project_meadow.jpg');"></div>
					</div>
				</div>
			</div>
		</div>
	</section> -->

	<section class="home-testimonials">
		<div class="container home-testimonials__container">
			<div class="home-testimonials__icon">
				<img src="<?= get_template_directory_uri(); ?>/assets/img/icon_quote.svg" />
			</div>
			<div class="home-testimonials__inner">
				<div class="home-testimonials__item">
					<h3 class="home-testimonials__title">Beespace is a design-led creative company</h3>
					<p class="home-testimonials__paragraph">We specialise in creating Co-living and Co-working spaces with a difference. We design and develop creative concepts which are unique in design and memorable in experience.“</p>
					<div class="home-testimonials__author">
						<img src="<?= get_template_directory_uri(); ?>/assets/img/author_1.png" />
						<div class="home-testimonials__author-right">
							<strong>Mike & Victoria Steinhouse</strong>
							Inside Property Investing
						</div>
					</div>
				</div>
				<div class="home-testimonials__item">
					<h3 class="home-testimonials__title">Beespace is a design-led creative company</h3>
					<p class="home-testimonials__paragraph">We specialise in creating Co-living and Co-working spaces with a difference. We design and develop creative concepts which are unique in design and memorable in experience.“</p>
					<div class="home-testimonials__author">
						<img src="<?= get_template_directory_uri(); ?>/assets/img/author_1.png" />
						<div class="home-testimonials__author-right">
							<strong>Mike & Victoria Steinhouse</strong>
							Inside Property Investing
						</div>
					</div>
				</div>
				<div class="home-testimonials__item">
					<h3 class="home-testimonials__title">Beespace is a design-led creative company</h3>
					<p class="home-testimonials__paragraph">We specialise in creating Co-living and Co-working spaces with a difference. We design and develop creative concepts which are unique in design and memorable in experience.“</p>
					<div class="home-testimonials__author">
						<img src="<?= get_template_directory_uri(); ?>/assets/img/author_1.png" />
						<div class="home-testimonials__author-right">
							<strong>Mike & Victoria Steinhouse</strong>
							Inside Property Investing
						</div>
					</div>
				</div>
			</div>
			<div class="home-testimonials__arrows">
				<div class="home-testimonials__prev home-testimonials__arrow">
					<img src="<?= get_template_directory_uri(); ?>/assets/img/icon_arrow-left.svg" />
				</div>
				<div class="home-testimonials__next home-testimonials__arrow">
					<img src="<?= get_template_directory_uri(); ?>/assets/img/icon_arrow-right.svg" />
				</div>
			</div>
		</div>
	</section>

	<?php

	$wp_query = new WP_Query( 'posts_per_page=3' );
	$first = ' first';

	if ( $wp_query->have_posts() ) : ?>

	<section class="home-blog">
		<div class="container home-blog__container">
			<div class="home-blog__top">
				<h2 class="home-blog__title">The Hive</h2>
				<a href="" class="button home-blog__button">View all posts</a>
			</div>
			<div class="home-blog__list">

		    <?php while ( $wp_query->have_posts() ) : 
		        $wp_query->the_post(); ?>

		        <?php $bg = wp_get_attachment_url( get_post_thumbnail_id()); ?>

		        <div class="home-blog__item">
		        	<a href="<?php echo the_permalink(); ?>">
						<img class="home-blog__item-image" src="<?php echo $bg ?>" />
					</a>
					<h6 class="home-blog__item-date"><?php echo the_date(); ?></h6>
					<a href="<?php echo the_permalink(); ?>">
						<h4 class="home-blog__item-title"><?php echo the_title(); ?></h4>
					</a>
					<a href="<?php echo the_permalink(); ?>" class="button button--outline home-blog__item-button">Read more</a>
				</div>

		        <?php
		    endwhile; //* end of one post ?>


		   </div>
		</div>
	</section>

	<?php endif; //* end loop

	wp_reset_query();

	?>

	<section class="footer-feature">
		<div class="container footer-feature__container">
			<div class="footer-feature__inner">
				<div class="footer-feature__item">Featured in</div>
				<div class="footer-feature__item"><img src="<?= get_template_directory_uri(); ?>/assets/img/feature_inside.png" /></div>
				<div class="footer-feature__item"><img src="<?= get_template_directory_uri(); ?>/assets/img/feature_property.png" /></div>
				<div class="footer-feature__item"><img src="<?= get_template_directory_uri(); ?>/assets/img/feature_hmo.png" /></div>
			</div>
		</div>
	</section>

<?php get_footer() ?>