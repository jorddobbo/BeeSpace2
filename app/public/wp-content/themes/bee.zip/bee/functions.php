<?php
/**
 * Sage includes
 *
 * The $sage_includes array determines the code library included in your theme.
 * Add or remove files to the array as needed. Supports child theme overrides.
 *
 * Please note that missing files will produce a fatal error.
 *
 * @link https://github.com/roots/sage/pull/1042
 */
$sage_includes = [
	'lib/assets.php',    // Scripts and stylesheets
	'lib/extras.php',    // Custom functions
	'lib/setup.php',     // Theme setup
	'lib/titles.php',    // Page titles
	'lib/fields.php'     // Page titles
];

// Register Custom Post Type
function custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Projects', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Project', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Projects', 'text_domain' ),
		'name_admin_bar'        => __( 'Projects', 'text_domain' ),
		'archives'              => __( 'Item Archives', 'text_domain' ),
		'attributes'            => __( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
		'all_items'             => __( 'All Items', 'text_domain' ),
		'add_new_item'          => __( 'Add New Item', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$rewrite = array(
		'slug'                  => 'projects',
		'with_front'            => true,
		'pages'                 => true,
		'feeds'                 => true,
	);
	$args = array(
		'label'                 => __( 'Project', 'text_domain' ),
		'description'           => __( 'Post Type Description', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'revisions', 'custom-fields' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-admin-multisite',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'project', $args );

}
add_action( 'init', 'custom_post_type', 0 );

function clicky_button($atts, $content = null) {
extract(shortcode_atts(array('link' => '#', 'target' => '','colour' => 'light', ), $atts));
return '<a class="button button--'.$colour.'" href="'.$link.'" target="'.$target.'">' . do_shortcode($content) . '<span></span></a>';
}
add_shortcode('button', 'clicky_button');

foreach ($sage_includes as $file) {
	if (!$filepath = locate_template($file)) {
		trigger_error(sprintf(__('Error locating %s for inclusion', 'themetitlelowercase'), $file), E_USER_ERROR);
	}
	require_once $filepath;
}
unset($file, $filepath);

/**
 * Enable ACF 5 early access
 * Requires at least version ACF 4.4.12 to work
 */
define('ACF_EARLY_ACCESS', '5');

function projects() {
    
ob_start(); ?>

<section class="home-projects">
	<div class="container home-projects__container">
		<div class="home-projects__top">
			<h2 class="home-projects__title">Our Projects</h2>
			<a href="/" class="button home-projects__button">View all projects</a>
		</div>
		<div class="home-projects__list">
		<?php
        
		    global $post;

		    //* The Query
		    $exec_query = new WP_Query( array (
		      'post_type' => 'project',
		      'posts_per_page' => -1
		    ) );
		    
		    //* The Loop
		    if ( $exec_query->have_posts() ) {

		    $postCount = 1; ?>
		    
		    <?php while ( $exec_query->have_posts() ): $exec_query->the_post();

		    $postCount++; ?>
		        
		    <?php $bg = wp_get_attachment_url( get_post_thumbnail_id($post->ID)); ?>
			
		    <div class="home-projects__item <?php if($postCount == 4) { ?>home-projects__item--full<?php } else { ?>home-projects__item--half<?php } ?>">
				<a class="home-projects__item-inner" href="<?php echo the_permalink(); ?>">
					<h3 class="home-projects__item-title"><?php echo the_title(); ?></h3>
					<div class="home-projects__item-image" style="background-image: url('<?php echo $bg; ?>');"></div>
				</a>
			</div>

			<?php endwhile; ?>
                  
			<?php wp_reset_postdata();

			}

			?>
		</div>
	</div>
</section>

<?php

	/* Get the buffered content into a var */
	$sc = ob_get_contents();

	/* Clean buffer */
	ob_end_clean();

	/* Return the content as usual */
	return $sc;

}
add_shortcode( 'projects', 'projects' );