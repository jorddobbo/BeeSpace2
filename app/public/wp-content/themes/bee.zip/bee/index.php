<?php get_header() ?>

<div class="title__banner">

	<div class="container">
		<div class="row">
			<h1 class="page-title"><?php the_title(); ?></h1>
		</div>
	</div>
</div>

<section class="home-blog">
	<div class="container home-blog__container">
		<div class="home-blog__top">
			<h2 class="home-blog__title">The Hive</h2>
			<a href="" class="button home-blog__button">View all posts</a>
		</div>
		<div class="home-blog__list">

<?php while (have_posts()) : the_post(); ?>

	<?php $bg = wp_get_attachment_url( get_post_thumbnail_id()); ?>

    <div class="home-blog__item">
    	<a href="<?php echo the_permalink(); ?>">
			<img class="home-blog__item-image" src="<?php echo $bg ?>" />
		</a>
		<h6 class="home-blog__item-date"><?php echo the_date(); ?></h6>
		<a href="<?php echo the_permalink(); ?>">
			<h4 class="home-blog__item-title"><?php echo the_title(); ?></h4>
		</a>
		<a href="<?php echo the_permalink(); ?>" class="button button--outline home-blog__item-button">Read more</a>
	</div>

<?php endwhile; ?>

</div>
	</div>
</section>

<?php the_posts_navigation(); ?>

<?php get_footer() ?>